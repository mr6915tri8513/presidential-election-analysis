drop database final;
create database final;
use final

CREATE TABLE Poll_stations(
    station_id INT,
    county_id TINYINT,
    district_id SMALLINT,
    village VARCHAR(15),
    PRIMARY KEY (station_id)
);

-- Load data into Poll_stations
Load data local infile './poll_stations.csv'
into table Poll_stations
fields terminated by ','
enclosed by '"'
lines terminated by '\n'
ignore 1 lines;

CREATE TABLE Poll_info(
    year SMALLINT,
    station_id INT,
    voter_count INT,
    PRIMARY KEY (year, station_id),
    FOREIGN KEY (station_id) REFERENCES Poll_stations(station_id)
);

-- Load data into Poll_info
Load data local infile './poll_info.csv'
into table Poll_info
fields terminated by ','
enclosed by '"'
lines terminated by '\n'
ignore 1 lines;

CREATE TABLE Polls(
    year SMALLINT,
    station_id INT,
    team INT,
    poll_count INT,
    PRIMARY KEY (year, station_id, team),
    FOREIGN KEY (year, station_id) REFERENCES Poll_info(year, station_id)
);

-- Load data into Polls
Load data local infile './polls.csv'
into table Polls
fields terminated by ','
enclosed by '"'
lines terminated by '\n'
ignore 1 lines;

CREATE TABLE Counties(
    county_id TINYINT,
    name VARCHAR(15),
    PRIMARY KEY (county_id)
);

-- Load data into Counties
Load data local infile './counties.csv'
into table Counties
fields terminated by ','
enclosed by '"'
lines terminated by '\n'
ignore 1 lines;

CREATE TABLE Districts(
    district_id SMALLINT,
    name VARCHAR(15),
    PRIMARY KEY (district_id)
);

-- Load data into Districts
Load data local infile './districts.csv'
into table Districts
fields terminated by ','
enclosed by '"'
lines terminated by '\n'
ignore 1 lines;

CREATE TABLE Parties(
    party_id TINYINT,
    name VARCHAR(15),
    PRIMARY KEY (party_id)
);

-- Load data into Parties
Load data local infile './parties.csv'
into table Parties
fields terminated by ','
enclosed by '"'
lines terminated by '\n'
ignore 1 lines;

CREATE TABLE Candidates(
    year SMALLINT,
    name VARCHAR(15),
    team INT,
    party_id TINYINT,
    position BOOLEAN,
    PRIMARY KEY (name, year)
    -- FOREIGN KEY (party_id) REFERENCES Candidates(party_id)
);

-- Load data into Candidates
Load data local infile './candidates.csv'
into table Candidates
fields terminated by ','
enclosed by '"'
lines terminated by '\n'
ignore 1 lines;

CREATE TABLE Users(
    user_id CHAR(10),
    user_password VARCHAR(31),
    username VARCHAR(31),
    vote_team TINYINT,
    station_id INT,
    PRIMARY KEY (user_id),
    FOREIGN KEY (station_id) REFERENCES Poll_stations(station_id)
);

